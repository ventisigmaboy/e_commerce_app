import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  // firebase authication instance
  final FirebaseAuth _auth = FirebaseAuth.instance;
  //firestore instance
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // function user sign up
  Future<String?> signUp({
    required String name,
    required String password,
    required String email,
    required String role,
  }) async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(
            email: email.trim(),
            password: password.trim(),
          );

      // save additional user data in firestore
      await _firestore.collection("users").doc(userCredential.user!.uid).set({
        'name': name.trim(),
        'email': email.trim(),
        'role': role, // determine if user or admin
      });
      return null; // success no error messages
    } catch (e) {
      return (e).toString(); // error messages
    }
  }

  // function user log in
  Future<String?> login({required String email, required String password}) async {
  try {
    print("🔥 Attempting login for email: $email");

    UserCredential userCredential = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password.trim(),
    );

    print("✅ User signed in: ${userCredential.user?.uid}");

    // Fetch user role from Firestore
    DocumentSnapshot userDoc = await _firestore
        .collection("users") // Ensure it's "users" not "user"
        .doc(userCredential.user!.uid)
        .get();

    if (!userDoc.exists) {
      print("❌ Error: User data not found in Firestore!");
      return "User data not found in Firestore!";
    }

    print("🎯 User role: ${userDoc['role']}");
    return userDoc['role']; // Should return "User" or "Admin"
  } catch (e) {
    print("🚨 Login failed: $e");
    return e.toString();
  }
}


  // for user sign out
  signOut() async {
    _auth.signOut();
  }
}
